# C# Tutorial – Make a Word Shuffle Game In Windows Form and Visual Studio

Hi, in this tutorial we will be making a word shuffle game in windows form. Words will be loaded from an external text file. We will add those words to the text file and load using C#. Each word in the text file will be saved as a list item then we will create a scramble function that will shuffle or scramble the words around in a random order and display it on the screen. There is a text box on the app to enter your  input, it will capture that input and compare it to the original word. If the word captured is correct then we will move on the next word from list and display to the screen or we will add 1 to the guessed integer.

# Video Tutorial - Click below to Watch this video on YouTube

[![](http://img.youtube.com/vi/e9w0JA2RWns/0.jpg)](https://www.youtube.com/watch?v=e9w0JA2RWns "MOO ICT C# Video Tutorial")

Subsribe to the youtube Channel to create more project just like this one.

[C# Tutorial – Make a Word Shuffle Game In Windows Form and Visual Studio](https://www.mooict.com/c-tutorial-make-a-word-shuffle-game-in-windows-form-and-visual-studio/)
